# BankingManagementSystem
This is a basic bank accounts management system application, build in springboot.
<p> <strong>Status:</strong> still working on, Open to every contributions and suggestions</p> 

<h4> Here is the basic ER diagram of this project : <h4/>
https://drive.google.com/file/d/1gGdHAEYZVwyu0cHoO32B-AQHmwRllv7Y/view?usp=sharing



<h2> Project Features and description </h2>
  <h3/> 
   
<ul dir="auto">
<li><strong>In this application people can sign up as a user</strong></li>
<li><strong>Can update details</strong></li>
<li><strong> Multiple sign up optins(Not implemneted)</strong></li>
<li><strong>Can open multiple accounts of different type with diferent passwords </strong></li>
  <ul dir="auto">
    <li>Saving</li>
    <li>Current</li>
    <li>Loan</li>
  </ul>
<li><strong>Every type of account will have different type of services and requirements (Not Implemented) </strong></li>
<li><strong>From every account user can make diffferent types to transactions after login to a particular account</strong></li>
<li><strong>Transaction types -</strong></li>
  <ul dir="auto">
    <li><strong>Money deposit</strong></li>
    <li><strong>Bank Transfer</strong></li>
    <li><strong>Withdrawal from bank </strong></li>
    <li><strong> Withdrawal through ATM(Not implemneted)</strong></li>
  </ul>
 <li><strong>User can get all transactions details </strong></li>
  <li><strong>Others as per requirements </strong></li>
</ul>

