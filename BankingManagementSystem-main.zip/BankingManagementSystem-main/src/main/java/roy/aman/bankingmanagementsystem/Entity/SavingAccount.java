package roy.aman.bankingmanagementsystem.Entity;

import javax.persistence.Entity;

@Entity
public class SavingAccount extends Account{

    // Account properties


    // ServiceAccount properties



    // Special Functionalities
}
