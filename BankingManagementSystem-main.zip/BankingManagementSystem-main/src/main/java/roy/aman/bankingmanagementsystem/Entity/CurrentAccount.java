package roy.aman.bankingmanagementsystem.Entity;

import javax.persistence.Entity;

@Entity
public class CurrentAccount extends Account{

    // Account properties


    // CurrentAccount properties



    // Special Functionalities of this account


}
