package roy.aman.bankingmanagementsystem.SupportEntity;

public class AtmTransDTO {
    Integer atmNumber;
    String password;
    Integer amount;
}

