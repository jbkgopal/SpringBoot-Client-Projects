package roy.aman.bankingmanagementsystem.Entity;

import javax.persistence.Entity;

@Entity
public class LoanAccount extends Account{

    // Account properties


    // LoanAccount properties



    // Special Functionalities of this account


}
