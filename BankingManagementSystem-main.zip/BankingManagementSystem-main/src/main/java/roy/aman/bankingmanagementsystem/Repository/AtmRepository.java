package roy.aman.bankingmanagementsystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import roy.aman.bankingmanagementsystem.Entity.ATM;

public interface AtmRepository extends JpaRepository<ATM, Long> {

}
