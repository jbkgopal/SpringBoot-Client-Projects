package roy.aman.bankingmanagementsystem.SupportEntity;

public enum TransactionType {
    DEPOSIT,WITHDRAW;
}
