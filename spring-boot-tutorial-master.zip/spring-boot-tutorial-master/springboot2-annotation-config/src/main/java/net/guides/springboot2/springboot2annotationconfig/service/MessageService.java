package net.guides.springboot2.springboot2annotationconfig.service;

public interface MessageService {
	public void sendMsg(String message);
}
