package net.guides.springboot2.springboot2javaconfig.service;

public interface MessageProcessor {
	public void processMsg(String message);
}
