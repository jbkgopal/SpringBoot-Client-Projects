package net.guides.springboot2.springboot2logging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboot2LoggingApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboot2LoggingApplication.class, args);
	}
}
