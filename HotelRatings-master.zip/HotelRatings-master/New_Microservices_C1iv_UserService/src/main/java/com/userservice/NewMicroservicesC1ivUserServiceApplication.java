package com.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewMicroservicesC1ivUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewMicroservicesC1ivUserServiceApplication.class, args);
	}

}
