package com.HotelService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewMicroservicesC1iiHotelServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
