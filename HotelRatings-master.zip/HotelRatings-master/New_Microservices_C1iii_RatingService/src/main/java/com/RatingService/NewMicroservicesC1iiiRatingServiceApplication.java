package com.RatingService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewMicroservicesC1iiiRatingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewMicroservicesC1iiiRatingServiceApplication.class, args);
	}

}
