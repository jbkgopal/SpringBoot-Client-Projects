document.getElementById("footer").innerHTML =
    `
    <br>
    <br>
    <br>
    <br>
    <p>@ 2023 Voting Application Made By Swapnil Ganpat Bamble.</p>
    `;