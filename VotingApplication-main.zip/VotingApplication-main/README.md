# VotingApplication
- It is a Javascript Application
- User can vote the Candidate, and Admin has the permission to see the vote details

### Technology used in this Project: 
Html,Css,Bootstrap,Javascript are used to build the project


## Try this Project url: https://swapnilbamble1438.github.io/VotingApplication/

### Software And Tools Required:
Visual Studio

### It is a Javascript Version, for Springboot version see https://github.com/swapnilbamble1438/VotingApp

