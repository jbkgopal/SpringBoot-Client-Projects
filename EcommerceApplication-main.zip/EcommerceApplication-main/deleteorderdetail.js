removeorderdetail();

function removeorderdetail()
{
    localStorage.removeItem("pcname");
    localStorage.removeItem("pemail");
 localStorage.removeItem("paddress");
  localStorage.removeItem("pcity");
   localStorage.removeItem("pstate");
  localStorage.removeItem("pcountry");
    localStorage.removeItem("ppincode");
}