let contentfooter = document.getElementById("footer");

let footer=`
<br>
<br>
<hr>
<br>
<center>

	<div class = "container">
	<div class = "row">
	
		<div class = "col-xxl-3 col-xl-3 col-lg-3 col-md-4 col-sm-6 col-xs-12">
			<div class = "container" style="background-color: white">
			<center>
				<h2>Online Electronic Store</h2>
				<p>Lorem ipsum dolor sit amet consl adipisi 
				elit, sed do eiusmod templ incididunt ut 
				labore</p>
			</center>
			</div>
		</div>
		
		<div class = "col-xxl-3 col-xl-3 col-lg-3 col-md-4 col-sm-6 col-xs-12">
			<div class = "container" style="background-color: white">
			<center>
				<h2>Services</h2>
				<p>Shopping Cart</p>
				<p>Shop</p>
				<p>Services Login</p>
				<p>Contact</p>
			</center>
			</div>
		</div>
		
		<div class = "col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12">
			<div class = "container" style="background-color: white">
			<center>
				<h2>Contact Info</h2>
				<p>Address: Your Address Goes Here. </p>
				<p>Phone/Fax: 0123456789</p>
				<p>Email: demo@example.com</p>
				<p>demo@example.com</p>
			</center>
			</div>
		</div>
		
		
		
	
	</div>
	</div>
	<br>
	<p>@ 2022 Online Electronic Shopping Made By Swapnil Ganpat Bamble.</p>
</center>

`;

contentfooter.innerHTML = footer;
