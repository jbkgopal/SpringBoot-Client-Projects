package roy.aman.employeemanagment.SupportEntity;

public enum Priority {
    High, Medium, Low
}