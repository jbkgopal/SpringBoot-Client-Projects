package spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringActionApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringActionApplication.class, args);
    }

}
