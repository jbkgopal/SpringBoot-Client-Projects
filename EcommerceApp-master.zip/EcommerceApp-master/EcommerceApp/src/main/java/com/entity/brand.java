package com.entity;

public class brand {
	
	private int bid;
	private String bname;

	public brand() {
	
	}

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}
	
	
	
}
