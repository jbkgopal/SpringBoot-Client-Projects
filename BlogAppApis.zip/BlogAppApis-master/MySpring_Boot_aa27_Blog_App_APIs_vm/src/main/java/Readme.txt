1) Swagger Configuration with Spring Security
2) Directly passing token from Swagger(UI)/(Web)
	and login from Swagger(UI)/(Web)
	
	
	
	Try this url in Browser after running Application
	http://localhost:8080/swagger-ui/index.html
	
	you will get all url's  