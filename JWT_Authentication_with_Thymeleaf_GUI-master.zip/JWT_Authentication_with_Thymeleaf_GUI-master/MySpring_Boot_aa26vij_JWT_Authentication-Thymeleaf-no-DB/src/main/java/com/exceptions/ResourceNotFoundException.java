package com.exceptions;

public class ResourceNotFoundException extends RuntimeException{
	

	public ResourceNotFoundException() {
	
		
	}

	
	
	

}
