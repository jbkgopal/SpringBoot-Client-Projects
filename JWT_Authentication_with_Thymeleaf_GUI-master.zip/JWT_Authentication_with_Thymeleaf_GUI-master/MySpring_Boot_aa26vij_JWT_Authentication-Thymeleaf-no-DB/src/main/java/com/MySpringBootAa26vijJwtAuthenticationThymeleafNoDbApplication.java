package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringBootAa26vijJwtAuthenticationThymeleafNoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootAa26vijJwtAuthenticationThymeleafNoDbApplication.class, args);
	}

}
