# MyPortfolio

A clean and simple portfolio template built for my self with plain HTML, CSS and JavaScript.

## Preview


[See Live] https://magical-kangaroo-d7625e.netlify.app/#top

## License goes to Aman Raj (https://github.com/ROY-AMAN)


