package uz.ATM.model;

public class Currency {
}
