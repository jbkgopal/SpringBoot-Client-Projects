package uz.ATM.model;

public enum CardType {
    UZCARD,
    HUMO,
    VISA,
    UNIONPAY;
}
