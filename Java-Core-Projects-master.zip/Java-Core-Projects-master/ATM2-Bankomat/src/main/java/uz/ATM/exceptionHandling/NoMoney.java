package uz.ATM.exceptionHandling;

public class NoMoney extends  Exception{
}
