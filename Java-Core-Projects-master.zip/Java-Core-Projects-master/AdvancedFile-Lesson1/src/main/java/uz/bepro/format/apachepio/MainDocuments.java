package uz.bepro.format.apachepio;

import java.io.IOException;


/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {AdvancedFile-Lesson1}
 * @Date: {2022/05/26 && 12:57 PM}
 */

public class MainDocuments {
    public static void main(String[] args) throws IOException {

        //Blank Document
//         XWPFDocument document = new XWPFDocument();
//
//        //Write the Document in file system
//       try ( FileOutputStream out = new FileOutputStream( new File("createdocument.docx"))){
//           document.write(out);
//       } catch (FileNotFoundException e){
//           e.printStackTrace();
//       }

        System.out.close();
        System.out.println("createdocument.docx written successully");
    }
}
