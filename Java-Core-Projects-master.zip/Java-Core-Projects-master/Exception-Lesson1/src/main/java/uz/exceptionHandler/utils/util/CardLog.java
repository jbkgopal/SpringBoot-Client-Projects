package uz.exceptionHandler.utils.util;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Exception-Lesson1}
 * @Date: {2022/05/19 && 9:11 PM}
 */
public class CardLog {
}
