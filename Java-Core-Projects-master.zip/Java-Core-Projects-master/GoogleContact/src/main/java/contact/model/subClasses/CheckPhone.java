package contact.model.subClasses;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {GoogleContact}
 * @Date: {2022/04/29 && 1:37 AM}
 */
public class CheckPhone {

    public static void checkPhone(){

    }
}
