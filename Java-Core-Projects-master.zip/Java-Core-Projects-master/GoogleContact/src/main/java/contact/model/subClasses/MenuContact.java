package contact.model.subClasses;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {GoogleContact}
 * @Date: {2022/04/27 && 6:16 PM}
 */
public class MenuContact {

    public static void showMenu(){

            System.out.println("MENU");
            System.out.println("O: Exit");
            System.out.println("1: Add contact");
            System.out.println("2: Edit contact");
            System.out.println("3: Search ");
            System.out.println("4: Delete contact");

        }
}
