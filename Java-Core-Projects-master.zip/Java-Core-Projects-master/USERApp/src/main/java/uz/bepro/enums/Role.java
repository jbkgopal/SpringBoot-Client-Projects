package uz.bepro.enums;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {TranslateApp}
 * @Date: {2022/05/10 && 9:19 AM}
 */
public enum Role {
    //
    ADMINISTRATOR,
    USER,
    GUEST
}
