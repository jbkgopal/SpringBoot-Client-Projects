package uz.bepro.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {TranslateApp}
 * @Date: {2022/05/10 && 9:21 AM}
 */
public interface UserService {
    //
    void create();
    void get();
    void update();
}
