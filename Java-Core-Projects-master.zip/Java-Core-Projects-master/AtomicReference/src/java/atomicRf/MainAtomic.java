package java.atomicRf;

/**
 * @Company: {Comp}
 * @Author: {urunov}
 * @Project: {AtomicReference}
 * @Date: {2022/05/13 && 2:12 PM}
 */
public class MainAtomic {
}
