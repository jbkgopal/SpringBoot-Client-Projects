package com.collection.project;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-3}
 * @Date: {2022/04/29 && 1:02 AM}
 */
@FunctionalInterface
public interface Test1 {
    void showMe();
}
