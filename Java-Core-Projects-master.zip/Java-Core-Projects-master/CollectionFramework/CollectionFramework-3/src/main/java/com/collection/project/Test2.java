package com.collection.project;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-3}
 * @Date: {2022/04/29 && 1:03 AM}
 */
public interface Test2 extends Test1 {

    public abstract void keepGoing();
}
