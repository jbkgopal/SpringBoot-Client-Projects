package com.collection.project;

import java.util.ArrayList;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-3}
 * @Date: {2022/04/27 && 5:58 PM}
 */
public class Word {
    //
    private String translation;
    private ArrayList<String> examples;
}
