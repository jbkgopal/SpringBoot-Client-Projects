package com.bepro.collections.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-2}
 * @Date: {2022/04/23 && 3:05 PM}
 */
public interface MoreMethods {
    //
    void calc();
    int cal(int val1);
    int umn(int value1, int number2);
}
