package com.bepro.collections.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-2}
 * @Date: {2022/04/23 && 3:55 PM}
 */
public class Phones {
    //
    private String name;
    private String model;
    private double price;


}
