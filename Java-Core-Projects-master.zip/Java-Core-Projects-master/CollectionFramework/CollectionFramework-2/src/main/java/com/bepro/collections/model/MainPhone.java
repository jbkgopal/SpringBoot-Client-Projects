package com.bepro.collections.model;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-2}
 * @Date: {2022/04/23 && 3:56 PM}
 */
public class MainPhone {
    public static void main(String[] args) {
        //
        Set<Phones> phonesSet = new LinkedHashSet<>();

    }
}
