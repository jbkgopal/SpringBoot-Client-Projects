package com.bepro.collections.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-2}
 * @Date: {2022/04/23 && 3:02 PM}
 */
@FunctionalInterface
public interface TestInterface {
    //
   public abstract boolean calculates(int number1, int number2);
}
