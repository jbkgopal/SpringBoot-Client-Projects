package com.bepro.collection;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-1}
 * @Date: {2022/04/22 && 12:51 AM}
 */
public interface MyList {
    //
    int size();
    void add();
    void add(int number);
    void remove();
    void remove(String text);

}
