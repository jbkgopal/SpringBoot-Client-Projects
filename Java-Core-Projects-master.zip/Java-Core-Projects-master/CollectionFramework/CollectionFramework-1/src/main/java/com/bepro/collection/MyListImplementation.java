package com.bepro.collection;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {CollectionFramework-1}
 * @Date: {2022/04/22 && 12:52 AM}
 */
public class MyListImplementation implements MyList{
    //

    @Override
    public int size() {
       //logic
        return 0;
    }

    @Override
    public void add() {

    }

    @Override
    public void add(int number) {

    }

    @Override
    public void remove() {

    }

    @Override
    public void remove(String text) {

    }
}
