package uz.academy.forInstance;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {DateTime-Lesson1}
 * @Date: {2022/05/12 && 2:34 PM}
 */
public class CarTest extends Car {

}
