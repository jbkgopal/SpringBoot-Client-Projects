package uz.bepro.academy;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {lessonOOPs}
 * @Date: {2022/03/30 && 1:13 AM}
 */
public class MainUniversity {
    public static void main(String[] args) {

    }
}
