package uz.bepro.academy;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {lessonOOPs}
 * @Date: {2022/03/30 && 1:12 AM}
 */
public class University {
    //
     
}
