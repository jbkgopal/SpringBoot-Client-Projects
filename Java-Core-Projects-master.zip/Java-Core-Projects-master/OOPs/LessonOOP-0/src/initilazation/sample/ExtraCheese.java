package initilazation.sample;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {ILikePizza}
 * @Date: {2022/03/30 && 7:25 PM}
 */
public class ExtraCheese {

    static int price = 129; // global variable
    public static void main(String[] args) {

        String pizza1 = "pipeline";
        String pizza2;
        pizza2 = "bbq";

        System.out.println(price);
    }

    public static void eatPizza(){
        System.out.println();
    }
}
