package fundamental.javaIns;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {ILikePizza}
 * @Date: {2022/03/30 && 7:39 PM}
 */
public class MyObject {
    public static void main(String[] args) {
        Eagle eagle = new Eagle();
        System.out.println(eagle instanceof Bird);
    }
}
