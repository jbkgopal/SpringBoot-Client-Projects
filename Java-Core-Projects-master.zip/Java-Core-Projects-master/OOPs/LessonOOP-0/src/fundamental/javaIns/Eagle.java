package fundamental.javaIns;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {ILikePizza}
 * @Date: {2022/03/30 && 7:39 PM}
 */
public class Eagle implements Bird{


    @Override
    public void sing() {
        System.out.println("Singing !");
    }
}
