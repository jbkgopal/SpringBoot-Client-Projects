package fundamental.javaIns;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {ILikePizza}
 * @Date: {2022/03/30 && 7:38 PM}
 */
public interface Bird {
    public void sing();
}
