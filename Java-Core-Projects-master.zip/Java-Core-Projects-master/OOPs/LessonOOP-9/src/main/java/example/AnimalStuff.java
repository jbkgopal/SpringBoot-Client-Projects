package example;

/**
 * @project: OOP-Project9
 * @Date: 02.08.2022
 * @author: H_Urunov
 **/
public interface AnimalStuff {

    //String color = null; // static and final
    // int age = 1
    public void poop();

}
