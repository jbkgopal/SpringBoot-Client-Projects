package uz.bepro.project.tasks;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 4:19 PM}
 */
public abstract class Animals {

    int eye = 2;
    abstract void voice();
}
