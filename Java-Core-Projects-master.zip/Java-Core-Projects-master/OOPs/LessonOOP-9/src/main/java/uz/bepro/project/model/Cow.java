package uz.bepro.project.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 2:29 PM}
 */
public class Cow extends Animal{
    //
    @Override
    public void voice() {
        System.out.println("Moo - moo");
    }
}
