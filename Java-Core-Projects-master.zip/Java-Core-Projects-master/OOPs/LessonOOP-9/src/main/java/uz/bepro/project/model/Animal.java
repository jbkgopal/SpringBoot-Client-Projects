package uz.bepro.project.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 1:48 PM}
 */
public abstract class Animal {

    public abstract void voice(); // public



//    public abstract void voice(); // optional
//    public void exactMethod(){
//        System.out.println("Exact method in here.");
//    }
//
//    int age =1;
//    public static double NUMBER_OF_EYE = 2;
//
//    public void about(){
//        System.out.println("I am animal...");
//    }
}
/*
*  Abstract class
*    - abstract Variable (o'zgaruvchi)
*    - abstract method
*
* */