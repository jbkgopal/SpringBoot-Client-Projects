package uz.bepro.project.tasks;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {InhertanceImp}
 * @Date: {2022/04/11 && 4:20 PM}
 */
public interface Live {

    void eat();
    void sleep();
    void walk();
}
