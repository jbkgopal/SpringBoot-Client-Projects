package com.project.oops;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {ClassObject}
 * @Date: {2022/03/16 && 1:19 AM}
 */
public class Teacher {

}
