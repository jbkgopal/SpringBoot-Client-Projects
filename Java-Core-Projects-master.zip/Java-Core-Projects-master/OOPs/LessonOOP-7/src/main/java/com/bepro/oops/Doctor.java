package com.bepro.oops;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Polymorphism}
 * @Date: {2022/04/06 && 10:39 PM}
 */
public class Doctor extends Employee{

    @Override
    public void work() {
        System.out.println("Doctor working");
    }
}
