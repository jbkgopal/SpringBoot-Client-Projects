package com.bepro.animals;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Polymorphism}
 * @Date: {2022/04/08 && 1:18 AM}
 */
public class CatChild extends Animal{

    @Override
    public void voice() {
        super.voice();
    }
}
