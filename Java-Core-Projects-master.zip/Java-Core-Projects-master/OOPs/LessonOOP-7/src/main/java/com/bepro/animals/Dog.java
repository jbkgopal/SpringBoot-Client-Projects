package com.bepro.animals;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Polymorphism}
 * @Date: {2022/04/06 && 10:53 PM}
 */
public class Dog extends Animal{
    //

    @Override
    public void voice() {
        super.voice();
    }

    @Override
    public String toString() {
        return super.toString();
    }


}
