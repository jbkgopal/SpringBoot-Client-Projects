package com.bepro.animals;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Polymorphism}
 * @Date: {2022/04/06 && 10:51 PM}
 */
public class Animal {
    //
    public void voice(){ // method
        System.out.println("wooo");
    }
}
