package uz.bepro.project.model.emp;

import uz.bepro.project.model.emp.Employee;
import uz.bepro.project.model.emp.Worker;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Lesson-10}
 * @Date: {2022/04/11 && 5:51 PM}
 */
public class MainPolyTest {
    public static void main(String[] args) {
        // step-1.
        Worker worker = new Worker();
        Employee.Programmer programmer = new Employee.Programmer();
        Employee.Designer designer;

        Employee.b =32;
        System.out.println(Employee.b);
    }
}

