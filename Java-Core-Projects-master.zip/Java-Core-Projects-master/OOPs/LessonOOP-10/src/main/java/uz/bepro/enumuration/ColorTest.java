package uz.bepro.enumuration;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Lesson-10}
 * @Date: {2022/04/12 && 5:42 PM}
 */
public class ColorTest {

    public static void main(String[] args) {
        Color color = Color.GREEN;
        System.out.println(color);
        color.colorInfo();
    }
}
