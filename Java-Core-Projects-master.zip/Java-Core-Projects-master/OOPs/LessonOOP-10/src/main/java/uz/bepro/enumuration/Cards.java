package uz.bepro.enumuration;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Lesson-10}
 * @Date: {2022/04/15 && 1:05 AM}
 */
public enum Cards {
    MasterCard,
    Visa,
    UnionPay,
    Uzcard,
    Humo,
    ATTO
}
