package uz.bepro.enumuration;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Lesson-10}
 * @Date: {2022/04/12 && 5:51 PM}
 */
public enum PizzaSize {
    SMALL, MEDIUM, LARGE, EXTRALARGE
}
