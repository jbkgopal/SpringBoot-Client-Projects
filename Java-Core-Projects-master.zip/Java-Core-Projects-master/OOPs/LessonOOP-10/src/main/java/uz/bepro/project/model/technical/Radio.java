package uz.bepro.project.model.technical;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Lesson-10}
 * @Date: {2022/04/14 && 7:14 PM}
 */
public class Radio implements RemoteController{

    @Override
    public void changeChannel() {

    }

    @Override
    public void changeValue() {

    }

    @Override
    public void changeLanguage() {

    }

    @Override
    public void extraMethod() {

    }

    @Override
    public void defaultMethod() {
        RemoteController.super.defaultMethod();
    }
}
