package uz.bepro.enumuration;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {Lesson-10}
 * @Date: {2022/04/15 && 1:06 AM}
 */
public class Bank {
    public static void main(String[] args) {
        Cards cards = Cards.MasterCard;

        // Logic


    }
}
