package uz.bepro.animals;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {JavaInhertance}
 * @Date: {2022/04/06 && 12:06 AM}
 */
public class Animal {
    //
    public String name;
    int age;
}
