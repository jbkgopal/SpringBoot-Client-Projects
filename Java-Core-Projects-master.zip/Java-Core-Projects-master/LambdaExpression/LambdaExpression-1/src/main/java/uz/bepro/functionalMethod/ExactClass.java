package uz.bepro.functionalMethod;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/15 && 6:30 PM}
 */
public class ExactClass implements Display{


    @Override
    public void switchValue() {
        System.out.println("Switch able to....");
    }

}
