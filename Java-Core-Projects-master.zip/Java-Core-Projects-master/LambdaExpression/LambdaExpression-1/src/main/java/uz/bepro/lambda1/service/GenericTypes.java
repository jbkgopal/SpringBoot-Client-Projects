package uz.bepro.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 10:41 PM}
 */
public interface GenericTypes <P, F, T>{

    T addValue(P a, F b);
}
