package uz.bepro.lambda1.service;

import uz.bepro.lambda1.domain.User;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/14 && 4:13 PM}
 */
public interface UserInterface {
    //
    User getUser(int number1, int number2);
}
