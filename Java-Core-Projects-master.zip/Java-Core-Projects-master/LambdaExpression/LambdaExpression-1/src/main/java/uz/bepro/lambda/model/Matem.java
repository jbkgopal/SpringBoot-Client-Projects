package uz.bepro.lambda.model;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 4:30 PM}
 */
public class Matem {

    public static int add(int a, int b){
        return a+b;
    }

    public static double add(double a, double b){
        return a + b;
    }
    public static int sub(int a, int b){
        return a-b;
    }

}
