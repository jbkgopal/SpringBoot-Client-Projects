package uz.bepro.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 10:34 PM}
 */
public interface GenericInterface <T> {
    // T - type
    T add(T number, T number1);

}
