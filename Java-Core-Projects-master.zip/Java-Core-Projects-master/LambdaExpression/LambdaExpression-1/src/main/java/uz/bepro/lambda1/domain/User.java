package uz.bepro.lambda1.domain;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/14 && 5:38 PM}
 */
public class User {
    //
    public int aNumber;
    public int bNumber;

    public User(int aNumber, int bNumber) {
        this.aNumber = aNumber;
        this.bNumber = bNumber;
    }
}
