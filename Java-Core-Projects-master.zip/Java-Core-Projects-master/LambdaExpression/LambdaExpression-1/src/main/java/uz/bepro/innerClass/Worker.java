package uz.bepro.innerClass;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/16 && 9:24 PM}
 */
class Worker {


}
