package uz.bepro.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 8:45 PM}
 */
public interface MaxCompare {

    int max(int number1, int number2);
}
