package uz.bepro.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 9:16 PM}
 */
@FunctionalInterface
public interface StringCompare {

    boolean isContain(String s1, String s2);
}
