package uz.bepro.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 9:04 PM}
 */
@FunctionalInterface
public interface DefineSignValue {
    void defineSign(double number);
}
