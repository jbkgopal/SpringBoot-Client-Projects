package uz.bepro.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/14 && 4:31 PM}
 */
public interface Expression {

    boolean isEqual(int number);
}
