package uz.bepro.lambda.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 6:21 PM}
 */
public interface Second {
    void showMe();
}
