package uz.bepro.lambda.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 4:16 PM}
 */
@FunctionalInterface
public interface Calculate {
    //

    int calc(int a, int b);
}
