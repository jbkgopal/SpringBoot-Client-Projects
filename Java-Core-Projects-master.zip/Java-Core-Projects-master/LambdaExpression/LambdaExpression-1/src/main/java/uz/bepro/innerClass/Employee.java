package uz.bepro.innerClass;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/15 && 5:44 PM}
 */
public class Employee {

    public int salary;
    public static int openPlace;

    // Inner class
    public static class Accounter{

    }

    public static class Progmmer{

    }


    public final static class Designer{ // impossible to use.

    }


}
