package uz.bepro.lambda.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 6:25 PM}
 */
public interface NoParam {
    //
    String operator();
}
