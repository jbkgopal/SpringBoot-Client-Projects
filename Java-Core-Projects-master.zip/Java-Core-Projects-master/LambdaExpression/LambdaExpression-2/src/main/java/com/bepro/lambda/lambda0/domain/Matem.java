package com.bepro.lambda.lambda0.domain;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 12:15 PM}
 */
public class Matem {

    public int add(int num1, int num2){
        return num1 + num2;
    }

    public int umn(int num1, int num2){
        return num1 * num2;
    }

}
