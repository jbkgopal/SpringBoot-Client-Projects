package com.bepro.lambda.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 2:44 PM}
 */
@FunctionalInterface
public interface Operationable {
    //
    boolean isEven(int a);

}
