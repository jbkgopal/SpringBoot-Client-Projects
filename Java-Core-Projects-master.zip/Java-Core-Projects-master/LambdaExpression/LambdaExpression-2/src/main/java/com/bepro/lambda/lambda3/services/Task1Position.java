package com.bepro.lambda.lambda3.services;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 6:53 PM}
 */
@FunctionalInterface
public interface Task1Position {
    //
    void defineSign(int number);
}
