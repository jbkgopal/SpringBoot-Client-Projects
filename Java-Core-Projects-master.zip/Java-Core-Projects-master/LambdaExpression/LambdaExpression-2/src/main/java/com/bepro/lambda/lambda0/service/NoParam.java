package com.bepro.lambda.lambda0.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 2:06 PM}
 */
@FunctionalInterface
public interface NoParam {
    //
    public abstract String operations();
}
