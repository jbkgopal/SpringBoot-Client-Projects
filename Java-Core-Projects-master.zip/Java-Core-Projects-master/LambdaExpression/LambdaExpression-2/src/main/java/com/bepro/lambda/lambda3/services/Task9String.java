package com.bepro.lambda.lambda3.services;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 10:02 PM}
 */
@FunctionalInterface
public interface Task9String {
    //
    boolean isContain(String s1, String s2);
}
