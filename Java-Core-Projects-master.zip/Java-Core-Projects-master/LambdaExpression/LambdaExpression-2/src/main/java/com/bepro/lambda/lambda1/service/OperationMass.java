package com.bepro.lambda.lambda1.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LessonOOP-11}
 * @Date: {2022/04/13 && 6:47 PM}
 */
@FunctionalInterface
public interface OperationMass {
    int oper(int[] nums);
}
