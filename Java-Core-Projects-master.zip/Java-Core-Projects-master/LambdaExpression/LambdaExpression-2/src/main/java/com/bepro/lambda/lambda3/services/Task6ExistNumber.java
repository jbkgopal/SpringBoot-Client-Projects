package com.bepro.lambda.lambda3.services;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 9:54 PM}
 */
@FunctionalInterface
public interface Task6ExistNumber {
    //
    boolean isExists(int [] nums, int number);

}
