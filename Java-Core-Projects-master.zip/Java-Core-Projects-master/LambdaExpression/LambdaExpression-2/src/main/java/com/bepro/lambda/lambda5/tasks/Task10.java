package com.bepro.lambda.lambda5.tasks;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-3}
 * @Date: {2022/04/21 && 1:24 PM}
 */
@FunctionalInterface
public interface Task10 {
    //
    int countVowel(String text);
}

// Berilgan matn ichida, bir nechta unli harf borligini aniqlang.