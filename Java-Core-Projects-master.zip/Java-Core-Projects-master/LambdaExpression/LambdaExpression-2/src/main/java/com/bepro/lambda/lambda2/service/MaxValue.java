package com.bepro.lambda.lambda2.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 4:04 PM}
 */
@FunctionalInterface
public interface MaxValue {
    //
    int compareValues(int num1, int num2);
}
