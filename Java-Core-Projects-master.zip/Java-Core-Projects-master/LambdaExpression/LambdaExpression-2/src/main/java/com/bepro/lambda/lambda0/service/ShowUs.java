package com.bepro.lambda.lambda0.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/19 && 1:58 PM}
 */
public interface ShowUs {

    void showMe();
    void tellMe();
}
