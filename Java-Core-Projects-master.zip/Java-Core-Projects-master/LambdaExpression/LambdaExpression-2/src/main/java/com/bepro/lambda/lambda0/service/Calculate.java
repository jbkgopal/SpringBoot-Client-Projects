package com.bepro.lambda.lambda0.service;

/**
 * @Company: {}
 * @Author: {urunov}
 * @Project: {LambdaExpression-2}
 * @Date: {2022/04/18 && 9:50 PM}
 */
@FunctionalInterface
public interface Calculate {
    // 1 abstract method.
    int calculate(int num1, int num2); //public abstract
}
